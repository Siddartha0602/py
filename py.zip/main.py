import pygame
import requests
from PIL import Image
import numpy as np
import sys
from io import BytesIO
import random

# Initialize Pygame
pygame.init()

# Set up display variables
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
SCREEN = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Memory Match Game")

# Load image from URL for start screen
image_url = "https://assets.nintendo.com/image/upload/c_fill,w_1200/q_auto:best/f_auto/dpr_2.0/ncom/software/switch/70010000067437/37d3ce1aa0c581e036179f4c57d19d33176bb43f6a600b475e4c6d84f3585ff2"
response = requests.get(image_url)
try:
    image = Image.open(BytesIO(response.content))
except Exception as e:
    print(f"Error loading image: {e}")
    pygame.quit()
    sys.exit()

# Fix image orientation
image = image.transpose(Image.ROTATE_270)  # Rotate 270 degrees
image = image.transpose(Image.FLIP_LEFT_RIGHT)  # Flip horizontally

# Resize image to fit screen while maintaining aspect ratio
image.thumbnail((SCREEN_WIDTH, SCREEN_HEIGHT))

# Convert image to Pygame surface
image_surface = pygame.surfarray.make_surface(np.array(image))

# Calculate image position to center on screen
image_x = (SCREEN_WIDTH - image_surface.get_width()) // 2
image_y = 50

# Define colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)

# Define font
FONT = pygame.font.SysFont("Arial", 30)

# Define play button
PLAY_BUTTON_WIDTH = 200
PLAY_BUTTON_HEIGHT = 50
PLAY_BUTTON_Y = image_y + image_surface.get_height() + 20
PLAY_BUTTON_X = (SCREEN_WIDTH - PLAY_BUTTON_WIDTH) // 2
PLAY_BUTTON = pygame.Rect(PLAY_BUTTON_X, PLAY_BUTTON_Y, PLAY_BUTTON_WIDTH, PLAY_BUTTON_HEIGHT)

# Game states
GAME_STATES = ["start", "game"]
current_game_state = GAME_STATES[0]

# Define card dimensions
CARD_WIDTH = 100
CARD_HEIGHT = 150

# Define card positions
CARD_SPACING = 20
CARD_COLUMNS = 4
CARD_ROWS = 3

# Calculate card positions to center on screen
CARD_START_X = (SCREEN_WIDTH - (CARD_WIDTH + CARD_SPACING) * CARD_COLUMNS + CARD_SPACING) // 2
CARD_START_Y = SCREEN_HEIGHT // 2 - (CARD_HEIGHT + CARD_SPACING) * CARD_ROWS // 2

# Define card values
CARD_VALUES = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6]

# Shuffle card values
random.shuffle(CARD_VALUES)

# Create card rectangles
CARDS = []
for i in range(CARD_ROWS):
    for j in range(CARD_COLUMNS):
        card_x = CARD_START_X + j * (CARD_WIDTH + CARD_SPACING)
        card_y = CARD_START_Y + i * (CARD_HEIGHT + CARD_SPACING)
        CARDS.append(pygame.Rect(card_x, card_y, CARD_WIDTH, CARD_HEIGHT))

# Initialize game variables
selected_cards = []
matches = 0
card_flipped = [False] * len(CARDS)
card_removed = [False] * len(CARDS)

# Main game loop
clock = pygame.time.Clock()
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if current_game_state == GAME_STATES[0] and PLAY_BUTTON.collidepoint(event.pos):
                current_game_state = GAME_STATES[1]
            elif current_game_state == GAME_STATES[1]:
                for i, card in enumerate(CARDS):
                    if card.collidepoint(event.pos) and not card_flipped[i] and not card_removed[i]:
                        if len(selected_cards) < 2:
                            selected_cards.append((card, CARD_VALUES[i]))
                            card_flipped[i] = True

    # Fill the background with white
    SCREEN.fill(WHITE)

    if current_game_state == GAME_STATES[0]:
        # Draw start screen
        SCREEN.blit(image_surface, (image_x, image_y))
        pygame.draw.rect(SCREEN, RED, PLAY_BUTTON)
        play_text = FONT.render("Play", True, BLACK)
        SCREEN.blit(play_text, (PLAY_BUTTON_X + PLAY_BUTTON_WIDTH // 2 - play_text.get_width() // 2,
                                PLAY_BUTTON_Y + PLAY_BUTTON_HEIGHT // 2 - play_text.get_height() // 2))
    elif current_game_state == GAME_STATES[1]:
        # Draw game screen
        for i, card in enumerate(CARDS):
            if card_removed[i]:
                continue
            elif card_flipped[i]:
                pygame.draw.rect(SCREEN, GREEN, card)
                font = pygame.font.Font(None, 100)
                text = font.render(str(CARD_VALUES[i]), True, RED)
                text_rect = text.get_rect(center=card.center)
                SCREEN.blit(text, text_rect)
            else:
                pygame.draw.rect(SCREEN, RED, card)

        # Check for matches
        if len(selected_cards) == 2:
            if selected_cards[0][1] == selected_cards[1][1]:
                matches += 1
                for i, card in enumerate(CARDS):
                    if card in [selected_cards[0][0], selected_cards[1][0]]:
                        card_removed[i] = True
            else:
                pygame.time.delay(500)
                for i, card in enumerate(CARDS):
                    if card in [selected_cards[0][0], selected_cards[1][0]]:
                        card_flipped[i] = False
            selected_cards = []

        # Check for game over
        if matches == len(CARD_VALUES) // 2:
            SCREEN.fill(WHITE)
            font = pygame.font.Font(None, 100)
            text = font.render("Game Over! You Win!", True, GREEN)
            text_rect = text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
            SCREEN.blit(text, text_rect)
            pygame.display.flip()
            pygame.time.delay(2000)
            pygame.quit()
            sys.exit()

    pygame.display.flip()
    clock.tick(60)
